pyrkube
~~~~~~~

Maintainer: Joe Black <joeblack949@gmail.com>
Repository: https://www.github.com/joeblackwaslike/pyrkube

This projects wraps the `pykube <https://github.com/kelproject/pykube>`_ project.

Description
-----------

A general purpose wrapper around the ``pykube`` library designed for situations
where having a readonly object as close to the actual Kubernetes API object
as possible.

This library was designed for use in Jinja templates for writing configuration
inside a container before application initialization and also to pause
a container until it's Kubernetes services are up.  It has been open sourced
in the case that it might be useful for someone else.
